# Guía de Despliegue para LBA UMG

## Opción 1: Hostinger (Sitio Estático)

### Pasos para desplegar en Hostinger:

1. **Instalar dependencias:**
   \`\`\`bash
   npm install
   \`\`\`

2. **Compilar el proyecto:**
   \`\`\`bash
   npm run build
   \`\`\`

3. **Ubicar los archivos compilados:**
   - Los archivos estáticos se generarán en la carpeta `out/`
   - Esta carpeta contiene todo el sitio web listo para subir

4. **Subir a Hostinger:**
   - Accede al panel de control de Hostinger
   - Ve a "Administrador de archivos" o usa FTP
   - Sube todo el contenido de la carpeta `out/` a la carpeta `public_html/` (o la carpeta raíz de tu dominio)

5. **Configuración adicional:**
   - Si tu sitio no está en la raíz del dominio, puede que necesites ajustar las rutas
   - Asegúrate de que el archivo `.htaccess` permita la navegación SPA

### Archivo .htaccess recomendado:

Crea un archivo `.htaccess` en la raíz con este contenido:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
