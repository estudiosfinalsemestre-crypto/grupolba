"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Image from "next/image"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u: any) => u.email === email && u.password === password)

    if (user || (email === "admin@lbaumg.edu.gt" && password === "admin123")) {
      localStorage.setItem("currentUser", JSON.stringify(user || { email, name: "Admin", role: "admin" }))
      router.push("/dashboard")
    } else {
      setError("Credenciales incorrectas")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />

      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-red-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <div className="w-full max-w-md relative z-10 animate-fade-in-up">
        <div className="bg-card border border-border rounded-2xl shadow-2xl p-8 backdrop-blur-sm">
          <div className="flex flex-col items-center mb-8">
            <div className="mb-4 animate-bounce-in">
              <Image
                src="/logo-umg.png"
                alt="LBA UMG Logo"
                width={120}
                height={120}
                className="rounded-full shadow-lg"
              />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">LBA UMG</h1>
            <p className="text-muted-foreground text-center">Sistema de Gestión de Usuarios</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2 animate-slide-in-left delay-200">
              <Label htmlFor="email">Correo Electrónico</Label>
              <Input
                id="email"
                type="email"
                placeholder="usuario@lbaumg.edu.gt"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            <div className="space-y-2 animate-slide-in-left delay-300">
              <Label htmlFor="password">Contraseña</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            {error && <div className="text-destructive text-sm text-center animate-shake">{error}</div>}

            <Button
              type="submit"
              className="w-full transition-all duration-300 hover:scale-105 hover:shadow-lg animate-slide-in-left delay-400"
            >
              Iniciar Sesión
            </Button>

            <div className="text-center animate-slide-in-left delay-500">
              <button
                type="button"
                onClick={() => router.push("/register")}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                ¿No tienes cuenta? <span className="text-primary font-semibold">Regístrate</span>
              </button>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-border text-center text-xs text-muted-foreground">
            Usuario demo: admin@lbaumg.edu.gt / admin123
          </div>
        </div>
      </div>
    </div>
  )
}
