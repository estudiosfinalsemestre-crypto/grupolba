"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Image from "next/image"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [error, setError] = useState("")

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      setError("Las contraseñas no coinciden")
      return
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]")

    if (users.find((u: any) => u.email === formData.email)) {
      setError("El correo ya está registrado")
      return
    }

    const newUser = {
      id: Date.now(),
      name: formData.name,
      email: formData.email,
      password: formData.password,
      role: "user",
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("users", JSON.stringify(users))

    router.push("/")
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />

      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 right-20 w-72 h-72 bg-red-500/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <div className="w-full max-w-md relative z-10 animate-fade-in-up">
        <div className="bg-card border border-border rounded-2xl shadow-2xl p-8 backdrop-blur-sm">
          <div className="flex flex-col items-center mb-8">
            <div className="mb-4 animate-bounce-in">
              <Image
                src="/logo-umg.png"
                alt="LBA UMG Logo"
                width={100}
                height={100}
                className="rounded-full shadow-lg"
              />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Crear Cuenta</h1>
            <p className="text-muted-foreground text-center">LBA UMG</p>
          </div>

          <form onSubmit={handleRegister} className="space-y-5">
            <div className="space-y-2 animate-slide-in-left delay-200">
              <Label htmlFor="name">Nombre Completo</Label>
              <Input
                id="name"
                type="text"
                placeholder="Juan Pérez"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            <div className="space-y-2 animate-slide-in-left delay-300">
              <Label htmlFor="email">Correo Electrónico</Label>
              <Input
                id="email"
                type="email"
                placeholder="usuario@lbaumg.edu.gt"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            <div className="space-y-2 animate-slide-in-left delay-400">
              <Label htmlFor="password">Contraseña</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            <div className="space-y-2 animate-slide-in-left delay-500">
              <Label htmlFor="confirmPassword">Confirmar Contraseña</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                required
                className="transition-all duration-300 focus:scale-105"
              />
            </div>

            {error && <div className="text-destructive text-sm text-center animate-shake">{error}</div>}

            <Button
              type="submit"
              className="w-full transition-all duration-300 hover:scale-105 hover:shadow-lg animate-slide-in-left delay-600"
            >
              Registrarse
            </Button>

            <div className="text-center animate-slide-in-left delay-700">
              <button
                type="button"
                onClick={() => router.push("/")}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                ¿Ya tienes cuenta? <span className="text-primary font-semibold">Inicia sesión</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
